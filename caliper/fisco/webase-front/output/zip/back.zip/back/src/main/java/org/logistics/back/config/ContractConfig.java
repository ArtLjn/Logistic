package org.logistics.back.config;

import java.lang.String;
import lombok.Data;

@Data
public class ContractConfig {
  private String logisticsControllerAddress;
}
