import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.fisco.bcos.sdk.abi.FunctionEncoder;
import org.fisco.bcos.sdk.abi.FunctionReturnDecoder;
import org.fisco.bcos.sdk.abi.TypeReference;
import org.fisco.bcos.sdk.abi.datatypes.Function;
import org.fisco.bcos.sdk.abi.datatypes.Type;
import org.fisco.bcos.sdk.abi.datatypes.Utf8String;
import org.fisco.bcos.sdk.abi.datatypes.generated.tuples.generated.Tuple1;
import org.fisco.bcos.sdk.client.Client;
import org.fisco.bcos.sdk.contract.Contract;
import org.fisco.bcos.sdk.crypto.CryptoSuite;
import org.fisco.bcos.sdk.crypto.keypair.CryptoKeyPair;
import org.fisco.bcos.sdk.model.CryptoType;
import org.fisco.bcos.sdk.model.TransactionReceipt;
import org.fisco.bcos.sdk.model.callback.TransactionCallback;
import org.fisco.bcos.sdk.transaction.model.exception.ContractException;

@SuppressWarnings("unchecked")
public class LogisticsController extends Contract {
    public static final String[] BINARY_ARRAY = {"608060405234801561001057600080fd5b506040516040806111398339810180604052810190808051906020019092919080519060200190929190505050816000806101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff16021790555080600160006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff160217905550505061106a806100cf6000396000f30060806040526004361061008e576000357c0100000000000000000000000000000000000000000000000000000000900463ffffffff1680630d392f0b146100935780633bdebb5c14610175578063484f87f3146102575780638c8622a0146103395780638e8f358d146103a257806391a91f6114610484578063dd29fbbc146104ed578063f5e0507214610556575b600080fd5b34801561009f57600080fd5b506100fa600480360381019080803590602001908201803590602001908080601f01602080910402602001604051908101604052809392919081815260200183838082843782019150505050505091929192905050506105bf565b6040518080602001828103825283818151815260200191508051906020019080838360005b8381101561013a57808201518184015260208101905061011f565b50505050905090810190601f1680156101675780820380516001836020036101000a031916815260200191505b509250505060405180910390f35b34801561018157600080fd5b506101dc600480360381019080803590602001908201803590602001908080601f016020809104026020016040519081016040528093929190818152602001838380828437820191505050505050919291929050505061074e565b6040518080602001828103825283818151815260200191508051906020019080838360005b8381101561021c578082015181840152602081019050610201565b50505050905090810190601f1680156102495780820380516001836020036101000a031916815260200191505b509250505060405180910390f35b34801561026357600080fd5b506102be600480360381019080803590602001908201803590602001908080601f01602080910402602001604051908101604052809392919081815260200183838082843782019150505050505091929192905050506108de565b6040518080602001828103825283818151815260200191508051906020019080838360005b838110156102fe5780820151818401526020810190506102e3565b50505050905090810190601f16801561032b5780820380516001836020036101000a031916815260200191505b509250505060405180910390f35b34801561034557600080fd5b506103a0600480360381019080803590602001908201803590602001908080601f0160208091040260200160405190810160405280939291908181526020018383808284378201915050505050509192919290505050610a6c565b005b3480156103ae57600080fd5b50610409600480360381019080803590602001908201803590602001908080601f0160208091040260200160405190810160405280939291908181526020018383808284378201915050505050509192919290505050610b7d565b6040518080602001828103825283818151815260200191508051906020019080838360005b8381101561044957808201518184015260208101905061042e565b50505050905090810190601f1680156104765780820380516001836020036101000a031916815260200191505b509250505060405180910390f35b34801561049057600080fd5b506104eb600480360381019080803590602001908201803590602001908080601f0160208091040260200160405190810160405280939291908181526020018383808284378201915050505050509192919290505050610d0d565b005b3480156104f957600080fd5b50610554600480360381019080803590602001908201803590602001908080601f0160208091040260200160405190810160405280939291908181526020018383808284378201915050505050509192919290505050610e1d565b005b34801561056257600080fd5b506105bd600480360381019080803590602001908201803590602001908080601f0160208091040260200160405190810160405280939291908181526020018383808284378201915050505050509192919290505050610f2e565b005b60606000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16639745bb36836040518263ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018080602001828103825283818151815260200191508051906020019080838360005b8381101561066a57808201518184015260208101905061064f565b50505050905090810190601f1680156106975780820380516001836020036101000a031916815260200191505b5092505050600060405180830381600087803b1580156106b657600080fd5b505af11580156106ca573d6000803e3d6000fd5b505050506040513d6000823e3d601f19601f8201168201806040525060208110156106f457600080fd5b81019080805164010000000081111561070c57600080fd5b8281019050602081018481111561072257600080fd5b815185600182028301116401000000008211171561073f57600080fd5b50509291905050509050919050565b6060600160009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16638516988f836040518263ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018080602001828103825283818151815260200191508051906020019080838360005b838110156107fa5780820151818401526020810190506107df565b50505050905090810190601f1680156108275780820380516001836020036101000a031916815260200191505b5092505050600060405180830381600087803b15801561084657600080fd5b505af115801561085a573d6000803e3d6000fd5b505050506040513d6000823e3d601f19601f82011682018060405250602081101561088457600080fd5b81019080805164010000000081111561089c57600080fd5b828101905060208101848111156108b257600080fd5b81518560018202830111640100000000821117156108cf57600080fd5b50509291905050509050919050565b60606000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1662677a8c836040518263ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018080602001828103825283818151815260200191508051906020019080838360005b8381101561098857808201518184015260208101905061096d565b50505050905090810190601f1680156109b55780820380516001836020036101000a031916815260200191505b5092505050600060405180830381600087803b1580156109d457600080fd5b505af11580156109e8573d6000803e3d6000fd5b505050506040513d6000823e3d601f19601f820116820180604052506020811015610a1257600080fd5b810190808051640100000000811115610a2a57600080fd5b82810190506020810184811115610a4057600080fd5b8151856001820283011164010000000082111715610a5d57600080fd5b50509291905050509050919050565b600160009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16639d145790826040518263ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018080602001828103825283818151815260200191508051906020019080838360005b83811015610b16578082015181840152602081019050610afb565b50505050905090810190601f168015610b435780820380516001836020036101000a031916815260200191505b5092505050600060405180830381600087803b158015610b6257600080fd5b505af1158015610b76573d6000803e3d6000fd5b5050505050565b6060600160009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663a2aca452836040518263ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018080602001828103825283818151815260200191508051906020019080838360005b83811015610c29578082015181840152602081019050610c0e565b50505050905090810190601f168015610c565780820380516001836020036101000a031916815260200191505b5092505050600060405180830381600087803b158015610c7557600080fd5b505af1158015610c89573d6000803e3d6000fd5b505050506040513d6000823e3d601f19601f820116820180604052506020811015610cb357600080fd5b810190808051640100000000811115610ccb57600080fd5b82810190506020810184811115610ce157600080fd5b8151856001820283011164010000000082111715610cfe57600080fd5b50509291905050509050919050565b6000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663cc894926826040518263ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018080602001828103825283818151815260200191508051906020019080838360005b83811015610db6578082015181840152602081019050610d9b565b50505050905090810190601f168015610de35780820380516001836020036101000a031916815260200191505b5092505050600060405180830381600087803b158015610e0257600080fd5b505af1158015610e16573d6000803e3d6000fd5b5050505050565b600160009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663fa26f838826040518263ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018080602001828103825283818151815260200191508051906020019080838360005b83811015610ec7578082015181840152602081019050610eac565b50505050905090810190601f168015610ef45780820380516001836020036101000a031916815260200191505b5092505050600060405180830381600087803b158015610f1357600080fd5b505af1158015610f27573d6000803e3d6000fd5b5050505050565b6000","809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663b81f4ac6826040518263ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018080602001828103825283818151815260200191508051906020019080838360005b83811015610fd7578082015181840152602081019050610fbc565b50505050905090810190601f1680156110045780820380516001836020036101000a031916815260200191505b5092505050600060405180830381600087803b15801561102357600080fd5b505af1158015611037573d6000803e3d6000fd5b50505050505600a165627a7a7230582081d0a7f83f7f6c21336e2ff5a844d6b75802683b2d5559531d0c7f13cad11c4c0029"};

    public static final String BINARY = org.fisco.bcos.sdk.utils.StringUtils.joinAll("", BINARY_ARRAY);

    public static final String[] SM_BINARY_ARRAY = {};

    public static final String SM_BINARY = org.fisco.bcos.sdk.utils.StringUtils.joinAll("", SM_BINARY_ARRAY);

    public static final String[] ABI_ARRAY = {"[{\"constant\":true,\"inputs\":[{\"name\":\"company_addr\",\"type\":\"string\"}],\"name\":\"GetPerChaseCompany\",\"outputs\":[{\"name\":\"\",\"type\":\"string\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"index\",\"type\":\"string\"}],\"name\":\"GetPerChaseOrder\",\"outputs\":[{\"name\":\"\",\"type\":\"string\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"company_addr\",\"type\":\"string\"}],\"name\":\"GetTransCompany\",\"outputs\":[{\"name\":\"\",\"type\":\"string\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"fields\",\"type\":\"string\"}],\"name\":\"CreatePerChaseOrder\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"index\",\"type\":\"string\"}],\"name\":\"GetTransOrder\",\"outputs\":[{\"name\":\"\",\"type\":\"string\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"_fields\",\"type\":\"string\"}],\"name\":\"CreateTransCompany\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"fields\",\"type\":\"string\"}],\"name\":\"CreateTransOrder\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"_fields\",\"type\":\"string\"}],\"name\":\"CreatePerChaseCompany\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"name\":\"company\",\"type\":\"address\"},{\"name\":\"order\",\"type\":\"address\"}],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"constructor\"}]"};

    public static final String ABI = org.fisco.bcos.sdk.utils.StringUtils.joinAll("", ABI_ARRAY);

    public static final String FUNC_GETPERCHASECOMPANY = "GetPerChaseCompany";

    public static final String FUNC_GETPERCHASEORDER = "GetPerChaseOrder";

    public static final String FUNC_GETTRANSCOMPANY = "GetTransCompany";

    public static final String FUNC_CREATEPERCHASEORDER = "CreatePerChaseOrder";

    public static final String FUNC_GETTRANSORDER = "GetTransOrder";

    public static final String FUNC_CREATETRANSCOMPANY = "CreateTransCompany";

    public static final String FUNC_CREATETRANSORDER = "CreateTransOrder";

    public static final String FUNC_CREATEPERCHASECOMPANY = "CreatePerChaseCompany";

    protected LogisticsController(String contractAddress, Client client, CryptoKeyPair credential) {
        super(getBinary(client.getCryptoSuite()), contractAddress, client, credential);
    }

    public static String getBinary(CryptoSuite cryptoSuite) {
        return (cryptoSuite.getCryptoTypeConfig() == CryptoType.ECDSA_TYPE ? BINARY : SM_BINARY);
    }

    public String GetPerChaseCompany(String company_addr) throws ContractException {
        final Function function = new Function(FUNC_GETPERCHASECOMPANY, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(company_addr)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeCallWithSingleValueReturn(function, String.class);
    }

    public String GetPerChaseOrder(String index) throws ContractException {
        final Function function = new Function(FUNC_GETPERCHASEORDER, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(index)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeCallWithSingleValueReturn(function, String.class);
    }

    public String GetTransCompany(String company_addr) throws ContractException {
        final Function function = new Function(FUNC_GETTRANSCOMPANY, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(company_addr)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeCallWithSingleValueReturn(function, String.class);
    }

    public TransactionReceipt CreatePerChaseOrder(String fields) {
        final Function function = new Function(
                FUNC_CREATEPERCHASEORDER, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(fields)), 
                Collections.<TypeReference<?>>emptyList());
        return executeTransaction(function);
    }

    public byte[] CreatePerChaseOrder(String fields, TransactionCallback callback) {
        final Function function = new Function(
                FUNC_CREATEPERCHASEORDER, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(fields)), 
                Collections.<TypeReference<?>>emptyList());
        return asyncExecuteTransaction(function, callback);
    }

    public String getSignedTransactionForCreatePerChaseOrder(String fields) {
        final Function function = new Function(
                FUNC_CREATEPERCHASEORDER, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(fields)), 
                Collections.<TypeReference<?>>emptyList());
        return createSignedTransaction(function);
    }

    public Tuple1<String> getCreatePerChaseOrderInput(TransactionReceipt transactionReceipt) {
        String data = transactionReceipt.getInput().substring(10);
        final Function function = new Function(FUNC_CREATEPERCHASEORDER, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        List<Type> results = FunctionReturnDecoder.decode(data, function.getOutputParameters());
        return new Tuple1<String>(

                (String) results.get(0).getValue()
                );
    }

    public String GetTransOrder(String index) throws ContractException {
        final Function function = new Function(FUNC_GETTRANSORDER, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(index)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeCallWithSingleValueReturn(function, String.class);
    }

    public TransactionReceipt CreateTransCompany(String _fields) {
        final Function function = new Function(
                FUNC_CREATETRANSCOMPANY, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(_fields)), 
                Collections.<TypeReference<?>>emptyList());
        return executeTransaction(function);
    }

    public byte[] CreateTransCompany(String _fields, TransactionCallback callback) {
        final Function function = new Function(
                FUNC_CREATETRANSCOMPANY, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(_fields)), 
                Collections.<TypeReference<?>>emptyList());
        return asyncExecuteTransaction(function, callback);
    }

    public String getSignedTransactionForCreateTransCompany(String _fields) {
        final Function function = new Function(
                FUNC_CREATETRANSCOMPANY, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(_fields)), 
                Collections.<TypeReference<?>>emptyList());
        return createSignedTransaction(function);
    }

    public Tuple1<String> getCreateTransCompanyInput(TransactionReceipt transactionReceipt) {
        String data = transactionReceipt.getInput().substring(10);
        final Function function = new Function(FUNC_CREATETRANSCOMPANY, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        List<Type> results = FunctionReturnDecoder.decode(data, function.getOutputParameters());
        return new Tuple1<String>(

                (String) results.get(0).getValue()
                );
    }

    public TransactionReceipt CreateTransOrder(String fields) {
        final Function function = new Function(
                FUNC_CREATETRANSORDER, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(fields)), 
                Collections.<TypeReference<?>>emptyList());
        return executeTransaction(function);
    }

    public byte[] CreateTransOrder(String fields, TransactionCallback callback) {
        final Function function = new Function(
                FUNC_CREATETRANSORDER, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(fields)), 
                Collections.<TypeReference<?>>emptyList());
        return asyncExecuteTransaction(function, callback);
    }

    public String getSignedTransactionForCreateTransOrder(String fields) {
        final Function function = new Function(
                FUNC_CREATETRANSORDER, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(fields)), 
                Collections.<TypeReference<?>>emptyList());
        return createSignedTransaction(function);
    }

    public Tuple1<String> getCreateTransOrderInput(TransactionReceipt transactionReceipt) {
        String data = transactionReceipt.getInput().substring(10);
        final Function function = new Function(FUNC_CREATETRANSORDER, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        List<Type> results = FunctionReturnDecoder.decode(data, function.getOutputParameters());
        return new Tuple1<String>(

                (String) results.get(0).getValue()
                );
    }

    public TransactionReceipt CreatePerChaseCompany(String _fields) {
        final Function function = new Function(
                FUNC_CREATEPERCHASECOMPANY, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(_fields)), 
                Collections.<TypeReference<?>>emptyList());
        return executeTransaction(function);
    }

    public byte[] CreatePerChaseCompany(String _fields, TransactionCallback callback) {
        final Function function = new Function(
                FUNC_CREATEPERCHASECOMPANY, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(_fields)), 
                Collections.<TypeReference<?>>emptyList());
        return asyncExecuteTransaction(function, callback);
    }

    public String getSignedTransactionForCreatePerChaseCompany(String _fields) {
        final Function function = new Function(
                FUNC_CREATEPERCHASECOMPANY, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(_fields)), 
                Collections.<TypeReference<?>>emptyList());
        return createSignedTransaction(function);
    }

    public Tuple1<String> getCreatePerChaseCompanyInput(TransactionReceipt transactionReceipt) {
        String data = transactionReceipt.getInput().substring(10);
        final Function function = new Function(FUNC_CREATEPERCHASECOMPANY, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        List<Type> results = FunctionReturnDecoder.decode(data, function.getOutputParameters());
        return new Tuple1<String>(

                (String) results.get(0).getValue()
                );
    }

    public static LogisticsController load(String contractAddress, Client client, CryptoKeyPair credential) {
        return new LogisticsController(contractAddress, client, credential);
    }

    public static LogisticsController deploy(Client client, CryptoKeyPair credential, String company, String order) throws ContractException {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Address(company), 
                new org.fisco.bcos.sdk.abi.datatypes.Address(order)));
        return deploy(LogisticsController.class, client, credential, getBinary(client.getCryptoSuite()), encodedConstructor);
    }
}
