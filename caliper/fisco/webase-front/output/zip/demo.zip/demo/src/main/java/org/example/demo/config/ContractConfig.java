package org.example.demo.config;

import java.lang.String;
import lombok.Data;

@Data
public class ContractConfig {
  private String newEnergyAddress;
}
